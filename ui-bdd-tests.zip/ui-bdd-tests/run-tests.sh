#!/usr/bin/env sh
set -eu

PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

if mvn -f "$PROJECT_DIR/pom.xml" clean test "$@"; then
	test_exit=0
else
	test_exit=$?
fi

if mvn -f "$PROJECT_DIR/pom.xml" io.qameta.allure:allure-maven:2.15.0:report; then
	report_exit=0
else
	report_exit=$?
fi

if [ "$test_exit" -ne 0 ]; then
	exit "$test_exit"
fi
exit "$report_exit"