# Storefront UI BDD Tests

Standalone Java, Selenium, and Cucumber tests for the Astronomy Shop storefront. This project has its own Maven build and does not depend on the demo's source tree or build. It uses only the browser-facing application and the feature-flag HTTP endpoint; it does not connect to a database or Kafka.

## Requirements

- Java 17 or newer
- Maven 3.9 or newer
- Google Chrome or Chromium
- The demo running at `http://localhost:8080/`
- Full Compose mode for the Kafka consumer-delay scenario

Selenium Manager resolves the ChromeDriver version. The first Maven run downloads test dependencies from Maven Central.

## Run

From this directory:

```sh
./run-tests.sh
```

Or run Maven directly:

```sh
mvn test
```

The default base URL is `http://localhost:8080/`. Override it with `BASE_URL`; set `HEADLESS=false` to open a visible browser.

```sh
BASE_URL=http://localhost:8080/ HEADLESS=false ./run-tests.sh
```

Test results are written under `target/surefire-reports/`.

## Scenarios

1. Product list, currency conversion, and currency persistence.
2. Cart quantity updates and persistence after refresh.
3. Successful order confirmation and empty cart after checkout.
4. Payment decline response and user-visible recovery state.
5. Order confirmation while the Kafka consumer is deliberately delayed.

The payment-decline scenario is expected to identify a current UI gap: the checkout API returns a structured payment error, but the cart form does not currently render that error. A failing assertion for the missing message is therefore a product finding, not a reason to weaken the expected behavior.

The Kafka scenario changes the demo's `kafkaQueueProblems` feature flag and verifies only the browser-visible result. It does not prove message delivery, consumer processing, database persistence, or deduplication. Those checks require Kafka/DB integration tests and are intentionally outside this project. Run the demo in full Compose mode for the scenario to exercise a real delayed consumer.

Feature flags changed by the suite are restored to their original values in Cucumber teardown. Run these tests against a disposable test deployment, not a shared environment where another user may be editing flags at the same time.

The demo's flag write API persists the flag document. When targeting a local Compose deployment with the repository mounted, a flag-mutating scenario can rewrite `src/flagd/demo.flagd.json` (including its formatting and schema header). Use a disposable deployment or restore that file after the run; the standalone test project intentionally does not access repository files.