# UI BDD Tests

Standalone Java, Selenium, and Cucumber tests for the Astronomy Shop. This project has its own Maven build and does not depend on the demo's source tree or build. Tests interact with the browser-facing application only.



## Requirements

- Java 17 or newer
- Maven 3.9 or newer
- Google Chrome or Chromium
- The demo running at `http://localhost:8080/`

Selenium Manager resolves the ChromeDriver version. The first Maven run downloads test dependencies from Maven Central.

## Run

From this directory:

```sh
./run-tests.sh
```

The wrapper runs a clean test build and automatically generates the Allure report, including when a test fails. Direct `mvn test` runs tests without generating the report.

The default base URL is `http://localhost:8080/`. Override it with `BASE_URL`; set `HEADLESS=false` to open a visible browser.

```sh
BASE_URL=http://localhost:8080/ HEADLESS=false ./run-tests.sh
```

Test scenarios run in parallel with up to four workers. Test results are written under `target/surefire-reports/`.

## Allure Report

The generated report is at `target/site/allure-maven-plugin/index.html`; raw results are in `target/allure-results`. Failed scenarios include a browser screenshot attachment when the browser is available. Scenario start, completion, and failure are logged through SLF4J.

## Structure

```text
src/test/java/org/opentelemetry/demo/ui/
	config/  Environment settings
	hooks/   Browser lifecycle
	pages/   Page objects
	steps/   Cucumber steps
```

## Scenarios

1. Product currency conversion and persistence.
2. Cart quantity updates and persistence after refresh.
3. Successful checkout and cart clearing.
4. Invalid card rejection and absence of order confirmation.

The invalid-card scenario currently fails because the storefront does not display the expected payment-error message. The test wrapper still generates the Allure report and exits with the test failure status.