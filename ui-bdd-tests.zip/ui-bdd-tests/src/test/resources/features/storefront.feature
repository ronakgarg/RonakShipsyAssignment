Feature: High-risk storefront journeys
  These browser tests exercise the demo through its public frontend only.

  Background:
    Given the storefront is open

  Scenario: Product browsing supports currency conversion and persistence
    When I select EUR
    Then product prices use the euro symbol
    When I reload the storefront
    Then EUR remains selected

  Scenario: Cart quantity survives an update and browser refresh
    When I add the first product twice
    Then the cart shows one item with quantity 2
    When I change the cart quantity to 3 and reload
    Then the cart shows one item with quantity 3

  Scenario: Successful checkout confirms the order and clears the cart
    Given the cart contains the first product
    When I submit checkout with valid demo details
    Then the order confirmation includes an order ID and the cart is empty

  Scenario: Invalid card details do not place an order
    Given the cart contains the first product
    When I submit checkout with invalid card details
    Then the invalid payment is rejected and no order confirmation appears

 