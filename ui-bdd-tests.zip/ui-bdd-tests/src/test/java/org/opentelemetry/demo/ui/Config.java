package org.opentelemetry.demo.ui;

public final class Config {
  private Config() {}

  public static String baseUrl() {
    String value = System.getenv().getOrDefault("BASE_URL", "http://localhost:8080/").trim();
    return value.endsWith("/") ? value : value + "/";
  }

  public static boolean headless() {
    return !"false".equalsIgnoreCase(System.getenv().getOrDefault("HEADLESS", "true"));
  }
}