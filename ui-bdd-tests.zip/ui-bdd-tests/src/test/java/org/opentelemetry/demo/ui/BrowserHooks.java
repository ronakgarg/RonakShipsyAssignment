package org.opentelemetry.demo.ui;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class BrowserHooks {
  private final TestWorld world;

  public BrowserHooks(TestWorld world) {
    this.world = world;
  }

  @Before
  public void startBrowser() {
    ChromeOptions options = new ChromeOptions();
    options.addArguments("--window-size=1440,1200");
    if (Config.headless()) {
      options.addArguments("--headless=new");
    }
    world.startBrowser(new ChromeDriver(options));
    world.driver.get(Config.baseUrl());
  }

  @After
  public void stopBrowser() {
    try {
      if (world.flagd != null) {
        world.flagd.restoreChangedFlags();
      }
    } finally {
      if (world.driver != null) {
        world.driver.quit();
      }
    }
  }
}