package org.opentelemetry.demo.ui;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TestWorld {
  public WebDriver driver;
  public WebDriverWait wait;
  public FlagdClient flagd;

  void startBrowser(WebDriver webDriver) {
    driver = webDriver;
    wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    flagd = new FlagdClient(Config.baseUrl());
  }
}