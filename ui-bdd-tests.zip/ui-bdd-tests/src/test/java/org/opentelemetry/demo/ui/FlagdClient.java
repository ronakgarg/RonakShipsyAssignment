package org.opentelemetry.demo.ui;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;

final class FlagdClient {
  private final ObjectMapper mapper = new ObjectMapper();
  private final HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
  private final URI readUri;
  private final URI writeUri;
  private final Map<String, JsonNode> originalFlags = new LinkedHashMap<>();

  FlagdClient(String baseUrl) {
    URI base = URI.create(baseUrl);
    readUri = base.resolve("/feature/api/read");
    writeUri = base.resolve("/feature/api/write");
  }

  void setDefaultVariant(String flagName, String variant) {
    try {
      ObjectNode config = readConfig();
      ObjectNode flags = (ObjectNode) config.path("flags");
      JsonNode flagNode = flags.get(flagName);
      if (!(flagNode instanceof ObjectNode flag) || !flag.path("variants").has(variant)) {
        throw new IllegalArgumentException("Unknown flag variant: " + flagName + "/" + variant);
      }
      originalFlags.putIfAbsent(flagName, flag.deepCopy());
      flag.put("defaultVariant", variant);
      writeConfig(config);
    } catch (Exception exception) {
      throw new IllegalStateException("Could not set feature flag " + flagName, exception);
    }
  }

  void restoreChangedFlags() {
    for (Map.Entry<String, JsonNode> entry : originalFlags.entrySet()) {
      try {
        ObjectNode config = readConfig();
        ((ObjectNode) config.path("flags")).set(entry.getKey(), entry.getValue());
        writeConfig(config);
      } catch (Exception exception) {
        throw new IllegalStateException("Could not restore feature flag " + entry.getKey(), exception);
      }
    }
    originalFlags.clear();
  }

  private ObjectNode readConfig() throws Exception {
    HttpRequest request = HttpRequest.newBuilder(readUri).timeout(Duration.ofSeconds(10)).GET().build();
    HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
    ensureSuccess(response.statusCode(), response.body());
    return (ObjectNode) mapper.readTree(response.body());
  }

  private void writeConfig(ObjectNode config) throws Exception {
    ObjectNode payload = mapper.createObjectNode();
    payload.set("data", config);
    HttpRequest request = HttpRequest.newBuilder(writeUri)
        .timeout(Duration.ofSeconds(10))
        .header("Content-Type", "application/json")
        .POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(payload)))
        .build();
    HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
    ensureSuccess(response.statusCode(), response.body());
  }

  private static void ensureSuccess(int statusCode, String body) {
    if (statusCode < 200 || statusCode >= 300) {
      throw new IllegalStateException("Feature-flag API returned HTTP " + statusCode + ": " + body);
    }
  }
}