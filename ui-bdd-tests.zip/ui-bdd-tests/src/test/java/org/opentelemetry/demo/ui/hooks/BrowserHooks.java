package org.opentelemetry.demo.ui.hooks;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import java.time.Duration;
import org.opentelemetry.demo.ui.config.Config;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BrowserHooks {
  private static final Logger LOGGER = LoggerFactory.getLogger(BrowserHooks.class);
  private WebDriver driver;
  private WebDriverWait wait;

  @Before
  public void startBrowser(Scenario scenario) {
    LOGGER.info("Starting scenario: {}", scenario.getName());
    ChromeOptions options = new ChromeOptions();
    options.addArguments("--window-size=1440,1200");
    if (Config.headless()) {
      options.addArguments("--headless=new");
    }
    driver = new ChromeDriver(options);
    wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    driver.get(Config.baseUrl());
  }

  @After
  public void stopBrowser(Scenario scenario) {
    try {
      if (scenario.isFailed()) {
        LOGGER.error("Scenario failed: {}", scenario.getName());
        attachFailureScreenshot(scenario);
      } else {
        LOGGER.info("Scenario finished: {} ({})", scenario.getName(), scenario.getStatus());
      }
    } finally {
      if (driver != null) {
        driver.quit();
      }
    }
  }

  public WebDriver driver() {
    return driver;
  }

  public WebDriverWait webDriverWait() {
    return wait;
  }

  private void attachFailureScreenshot(Scenario scenario) {
    if (driver == null) {
      LOGGER.warn("Cannot capture failure screenshot; browser was not started");
      return;
    }
    try {
      byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
      scenario.attach(screenshot, "image/png", "Failure screenshot");
      LOGGER.info("Attached failure screenshot for scenario: {}", scenario.getName());
    } catch (WebDriverException exception) {
      LOGGER.warn("Could not capture failure screenshot for scenario: {}", scenario.getName(), exception);
    }
  }
}