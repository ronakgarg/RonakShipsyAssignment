package org.opentelemetry.demo.ui.pages;

import org.opentelemetry.demo.ui.config.Config;
import org.opentelemetry.demo.ui.hooks.BrowserHooks;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

public final class HomePage extends BasePage {
  private static final By PRODUCT_CARDS = By.cssSelector("[data-cy='product-card']");
  private static final By CURRENCY_SWITCHER = By.cssSelector("[data-cy='currency-switcher']");
  private static final By PRODUCT_PRICES = By.cssSelector("[data-cy='product-price']");

  public HomePage(BrowserHooks browser) {
    super(browser);
  }

  public void open() {
    driver().get(Config.baseUrl());
    waitForProducts();
  }

  public void waitForProducts() {
    waitForElements(PRODUCT_CARDS);
  }

  public int productCount() {
    return driver().findElements(PRODUCT_CARDS).size();
  }

  public void chooseCurrency(String currencyCode) {
    new Select(waitForVisible(CURRENCY_SWITCHER)).selectByValue(currencyCode);
    waitForValue(CURRENCY_SWITCHER, currencyCode);
  }

  public String selectedCurrency() {
    return new Select(waitForVisible(CURRENCY_SWITCHER)).getFirstSelectedOption().getDomProperty("value");
  }

  public String firstProductPrice() {
    return waitForNonBlankText(PRODUCT_PRICES);
  }

  public void openFirstProduct() {
    waitForElements(PRODUCT_CARDS).get(0).click();
    waitForUrlContains("/product/");
  }
}