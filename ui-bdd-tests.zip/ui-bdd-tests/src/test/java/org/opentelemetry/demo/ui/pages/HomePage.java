package org.opentelemetry.demo.ui.pages;

import java.util.List;
import org.opentelemetry.demo.ui.Config;
import org.opentelemetry.demo.ui.TestWorld;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public final class HomePage extends BasePage {
  private static final By PRODUCT_CARDS = By.cssSelector("[data-cy='product-card']");
  private static final By CURRENCY_SWITCHER = By.cssSelector("[data-cy='currency-switcher']");
  private static final By PRODUCT_PRICES = By.cssSelector("[data-cy='product-price']");

  public HomePage(TestWorld world) {
    super(world);
  }

  public void open() {
    world.driver.get(Config.baseUrl());
    waitForProducts();
  }

  public void waitForProducts() {
    world.wait.until(driver -> !driver.findElements(PRODUCT_CARDS).isEmpty());
  }

  public int productCount() {
    return world.driver.findElements(PRODUCT_CARDS).size();
  }

  public void chooseCurrency(String currencyCode) {
    new Select(visible(CURRENCY_SWITCHER)).selectByValue(currencyCode);
    world.wait.until(driver -> currencyCode.equals(new Select(driver.findElement(CURRENCY_SWITCHER))
        .getFirstSelectedOption().getDomProperty("value")));
  }

  public String selectedCurrency() {
    return new Select(visible(CURRENCY_SWITCHER)).getFirstSelectedOption().getDomProperty("value");
  }

  public String firstProductPrice() {
    return world.wait.until(driver -> {
      List<WebElement> prices = driver.findElements(PRODUCT_PRICES);
      return prices.isEmpty() || prices.get(0).getText().isBlank() ? null : prices.get(0).getText();
    });
  }

  public void openFirstProduct() {
    world.wait.until(driver -> !driver.findElements(PRODUCT_CARDS).isEmpty());
    world.driver.findElements(PRODUCT_CARDS).get(0).click();
    world.wait.until(driver -> driver.getCurrentUrl().contains("/product/"));
  }
}