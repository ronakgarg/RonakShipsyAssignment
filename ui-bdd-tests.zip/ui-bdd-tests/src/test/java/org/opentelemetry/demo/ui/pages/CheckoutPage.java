package org.opentelemetry.demo.ui.pages;

import java.time.LocalDate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.opentelemetry.demo.ui.TestWorld;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public final class CheckoutPage extends BasePage {
  private static final By ORDER_COMPLETE = By.xpath("//*[contains(normalize-space(), 'Your order is complete!')]");
  private static final Pattern ORDER_ID = Pattern.compile("Order ID:\\s*([a-fA-F0-9-]{20,})");

  public CheckoutPage(TestWorld world) {
    super(world);
  }

  public void fillValidDemoDetails() {
    replace("email", "qa-tests@example.com");
    replace("street_address", "1600 Amphitheatre Parkway");
    replace("zip_code", "94043");
    replace("city", "Mountain View");
    replace("state", "CA");
    replace("country", "United States");
    replace("credit_card_number", "4432-8015-6152-0454");
    replace("credit_card_cvv", "672");
    select("credit_card_expiration_month", "1");
    select("credit_card_expiration_year", Integer.toString(LocalDate.now().getYear() + 2));
  }

  public void captureCheckoutResponse() {
    ((JavascriptExecutor) world.driver).executeScript("""
        window.__uiBddCheckoutStatus = null;
        const originalFetch = window.fetch.bind(window);
        window.fetch = (...args) => originalFetch(...args).then(response => {
          if (String(args[0]).includes('/api/checkout')) {
            window.__uiBddCheckoutStatus = response.status;
          }
          return response;
        });
        """);
  }

  public void submit() {
    new CartPage(world).submitCheckout();
    world.wait.until(driver -> ((JavascriptExecutor) driver)
        .executeScript("return window.__uiBddCheckoutStatus") != null);
  }

  public int checkoutStatus() {
    Object status = ((JavascriptExecutor) world.driver).executeScript("return window.__uiBddCheckoutStatus");
    return ((Number) status).intValue();
  }

  public boolean isOrderComplete() {
    return !world.driver.findElements(ORDER_COMPLETE).isEmpty();
  }

  public String orderId() {
    Matcher matcher = ORDER_ID.matcher(bodyText());
    return matcher.find() ? matcher.group(1) : "";
  }

  public boolean showsPaymentFailure() {
    return bodyText().contains("Your payment could not be processed.");
  }

  private void replace(String id, String value) {
    WebElement input = visible(By.id(id));
    input.clear();
    input.sendKeys(value);
  }

  private void select(String id, String value) {
    new Select(visible(By.id(id))).selectByValue(value);
  }
}