package org.opentelemetry.demo.ui.pages;

import java.time.LocalDate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.opentelemetry.demo.ui.hooks.BrowserHooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public final class CheckoutPage extends BasePage {
  private static final By ORDER_COMPLETE = By.xpath("//*[contains(normalize-space(), 'Your order is complete!')]");
  private static final By PAYMENT_FAILURE = By.xpath("//*[contains(normalize-space(), 'Your payment could not be processed.')]");
  private static final Pattern ORDER_ID = Pattern.compile("Order ID:\\s*([a-fA-F0-9-]{20,})");

  public CheckoutPage(BrowserHooks browser) {
    super(browser);
  }

  public void fillValidDemoDetails() {
    replace("email", "qa-tests@example.com");
    replace("street_address", "1600 Amphitheatre Parkway");
    replace("zip_code", "94043");
    replace("city", "Mountain View");
    replace("state", "CA");
    replace("country", "United States");
    replace("credit_card_number", "4432-8015-6152-0454");
    replace("credit_card_cvv", "672");
    select("credit_card_expiration_month", "1");
    select("credit_card_expiration_year", Integer.toString(LocalDate.now().getYear() + 2));
  }

  public void fillInvalidCardDetails() {
    fillValidDemoDetails();
    replace("credit_card_number", "0000-0000-0000-0000");
  }

  public void submit() {
    new CartPage(browser).submitCheckout();
  }

  public void waitForOrderComplete() {
    waitForVisible(ORDER_COMPLETE);
  }

  public void waitForPaymentFailure() {
    waitForVisible(PAYMENT_FAILURE);
  }

  public boolean isOrderComplete() {
    return isPresent(ORDER_COMPLETE);
  }

  public String orderId() {
    Matcher matcher = ORDER_ID.matcher(bodyText());
    return matcher.find() ? matcher.group(1) : "";
  }

  private void replace(String id, String value) {
    WebElement input = waitForVisible(By.id(id));
    input.clear();
    input.sendKeys(value);
  }

  private void select(String id, String value) {
    new Select(waitForVisible(By.id(id))).selectByValue(value);
  }
}