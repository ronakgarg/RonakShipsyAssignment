package org.opentelemetry.demo.ui.pages;

import org.opentelemetry.demo.ui.TestWorld;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public abstract class BasePage {
  protected final TestWorld world;

  protected BasePage(TestWorld world) {
    this.world = world;
  }

  protected WebElement visible(By locator) {
    return world.wait.until(driver -> {
      WebElement element = driver.findElement(locator);
      return element.isDisplayed() ? element : null;
    });
  }

  protected void click(By locator) {
    visible(locator).click();
  }

  protected String bodyText() {
    return world.driver.findElement(By.tagName("body")).getText();
  }
}