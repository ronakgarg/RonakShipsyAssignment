package org.opentelemetry.demo.ui.pages;

import java.util.List;
import org.opentelemetry.demo.ui.hooks.BrowserHooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public abstract class BasePage {
  protected final BrowserHooks browser;

  protected BasePage(BrowserHooks browser) {
    this.browser = browser;
  }

  protected WebDriver driver() {
    return browser.driver();
  }

  protected WebDriverWait webDriverWait() {
    return browser.webDriverWait();
  }

  protected WebElement waitForVisible(By locator) {
    return webDriverWait().until(ExpectedConditions.visibilityOfElementLocated(locator));
  }

  protected List<WebElement> waitForElements(By locator) {
    return webDriverWait().until(ExpectedConditions.presenceOfAllElementsLocatedBy(locator));
  }

  protected void waitForElementCount(By locator, int count) {
    webDriverWait().until(ExpectedConditions.numberOfElementsToBe(locator, count));
  }

  protected void waitForValue(By locator, String value) {
    webDriverWait().until(ExpectedConditions.textToBePresentInElementValue(locator, value));
  }

  protected void waitForUrlContains(String value) {
    webDriverWait().until(ExpectedConditions.urlContains(value));
  }

  protected void waitForUrlMatches(String regex) {
    webDriverWait().until(ExpectedConditions.urlMatches(regex));
  }

  protected String waitForNonBlankText(By locator) {
    return webDriverWait().until(driver -> {
      List<WebElement> elements = driver.findElements(locator);
      if (elements.isEmpty() || elements.get(0).getText().isBlank()) {
        return null;
      }
      return elements.get(0).getText();
    });
  }

  protected boolean isPresent(By locator) {
    return !driver().findElements(locator).isEmpty();
  }

  protected void click(By locator) {
    waitForVisible(locator).click();
  }

  protected String bodyText() {
    return driver().findElement(By.tagName("body")).getText();
  }
}