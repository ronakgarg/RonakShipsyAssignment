package org.opentelemetry.demo.ui.pages;

import java.util.List;
import org.opentelemetry.demo.ui.Config;
import org.opentelemetry.demo.ui.TestWorld;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

public final class CartPage extends BasePage {
  private static final By QUANTITY_SELECTS = By.cssSelector("main section select");
  private static final By PLACE_ORDER = By.cssSelector("[data-cy='checkout-place-order']");
  private static final By EMPTY_CART_MESSAGE = By.xpath("//*[contains(normalize-space(), 'Your shopping cart is empty!')]");

  public CartPage(TestWorld world) {
    super(world);
  }

  public void open() {
    world.driver.get(Config.baseUrl() + "cart");
  }

  public int itemCount() {
    return world.driver.findElements(QUANTITY_SELECTS).size();
  }

  public List<String> quantities() {
    return world.driver.findElements(QUANTITY_SELECTS).stream()
        .map(select -> new Select(select).getFirstSelectedOption().getDomProperty("value"))
        .toList();
  }

  public void waitForItems(int count) {
    world.wait.until(driver -> driver.findElements(QUANTITY_SELECTS).size() == count);
  }

  public void setFirstQuantity(String quantity) {
    world.wait.until(driver -> !driver.findElements(QUANTITY_SELECTS).isEmpty());
    new Select(world.driver.findElements(QUANTITY_SELECTS).get(0)).selectByValue(quantity);
    world.wait.until(driver -> quantity.equals(new Select(driver.findElements(QUANTITY_SELECTS).get(0))
        .getFirstSelectedOption().getDomProperty("value")));
  }

  public boolean isEmpty() {
    return world.wait.until(driver -> !driver.findElements(EMPTY_CART_MESSAGE).isEmpty());
  }

  public String visibleText() {
    return bodyText();
  }

  public void submitCheckout() {
    click(PLACE_ORDER);
  }
}