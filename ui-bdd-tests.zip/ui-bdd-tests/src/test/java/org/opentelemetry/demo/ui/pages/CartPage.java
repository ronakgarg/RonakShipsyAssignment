package org.opentelemetry.demo.ui.pages;

import java.util.List;
import org.opentelemetry.demo.ui.config.Config;
import org.opentelemetry.demo.ui.hooks.BrowserHooks;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

public final class CartPage extends BasePage {
  private static final By QUANTITY_SELECTS = By.cssSelector("main section select");
  private static final By PLACE_ORDER = By.cssSelector("[data-cy='checkout-place-order']");
  private static final By EMPTY_CART_MESSAGE = By.xpath("//*[contains(normalize-space(), 'Your shopping cart is empty!')]");

  public CartPage(BrowserHooks browser) {
    super(browser);
  }

  public void open() {
    driver().get(Config.baseUrl() + "cart");
  }

  public int itemCount() {
    return driver().findElements(QUANTITY_SELECTS).size();
  }

  public List<String> quantities() {
    return driver().findElements(QUANTITY_SELECTS).stream()
        .map(select -> new Select(select).getFirstSelectedOption().getDomProperty("value"))
        .toList();
  }

  public void waitForItems(int count) {
    waitForElementCount(QUANTITY_SELECTS, count);
  }

  public void setFirstQuantity(String quantity) {
    new Select(waitForVisible(QUANTITY_SELECTS)).selectByValue(quantity);
    waitForValue(QUANTITY_SELECTS, quantity);
  }

  public boolean isEmpty() {
    return waitForVisible(EMPTY_CART_MESSAGE).isDisplayed();
  }

  public String visibleText() {
    return bodyText();
  }

  public void submitCheckout() {
    click(PLACE_ORDER);
  }
}