package org.opentelemetry.demo.ui;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.opentelemetry.demo.ui.pages.CartPage;
import org.opentelemetry.demo.ui.pages.CheckoutPage;
import org.opentelemetry.demo.ui.pages.HomePage;
import org.opentelemetry.demo.ui.pages.ProductPage;

public class StorefrontSteps {
  private final TestWorld world;
  private final HomePage home;
  private final ProductPage product;
  private final CartPage cart;
  private final CheckoutPage checkout;

  public StorefrontSteps(TestWorld world) {
    this.world = world;
    home = new HomePage(world);
    product = new ProductPage(world);
    cart = new CartPage(world);
    checkout = new CheckoutPage(world);
  }

  @Given("the storefront is open")
  public void storefrontIsOpen() {
    home.waitForProducts();
    assertTrue(home.productCount() > 0, "The homepage should show products");
  }

  @When("I select EUR")
  public void selectEuro() {
    home.chooseCurrency("EUR");
  }

  @Then("product prices use the euro symbol")
  public void pricesUseEuro() {
    assertTrue(home.firstProductPrice().contains("€"), "Expected a EUR product price");
  }

  @When("I reload the storefront")
  public void reloadStorefront() {
    home.open();
  }

  @Then("EUR remains selected")
  public void euroRemainsSelected() {
    assertEquals("EUR", home.selectedCurrency());
  }

  @When("I add the first product twice")
  public void addFirstProductTwice() {
    home.openFirstProduct();
    product.addToCart();
    home.open();
    home.openFirstProduct();
    product.addToCart();
  }

  @Then("the cart shows one item with quantity {int}")
  public void cartShowsQuantity(int quantity) {
    cart.open();
    cart.waitForItems(1);
    assertEquals(Integer.toString(quantity), cart.quantities().get(0));
  }

  @When("I change the cart quantity to {int} and reload")
  public void changeQuantityAndReload(int quantity) {
    cart.setFirstQuantity(Integer.toString(quantity));
    world.driver.navigate().refresh();
    cart.waitForItems(1);
  }

  @Given("the cart contains the first product")
  public void cartContainsFirstProduct() {
    home.openFirstProduct();
    product.addToCart();
    cart.waitForItems(1);
  }

  @Given("payment failures are enabled")
  public void paymentFailuresAreEnabled() {
    world.flagd.setDefaultVariant("paymentFailure", "100%");
  }

  @Given("the Kafka consumer is delayed")
  public void kafkaConsumerIsDelayed() {
    world.flagd.setDefaultVariant("kafkaQueueProblems", "5sec");
  }

  @When("I submit checkout with valid demo details")
  public void submitCheckout() {
    checkout.fillValidDemoDetails();
    checkout.captureCheckoutResponse();
    checkout.submit();
  }

  @Then("the order confirmation includes an order ID and the cart is empty")
  public void orderConfirmedAndCartEmpty() {
    assertEquals(200, checkout.checkoutStatus(), "Checkout should return HTTP 200");
    world.wait.until(driver -> checkout.isOrderComplete());
    assertFalse(checkout.orderId().isBlank(), "Order confirmation should contain an order ID");
    cart.open();
    assertTrue(cart.isEmpty(), "The backend should have emptied the cart");
  }

  @Then("the payment failure is shown and checkout does not complete")
  public void paymentFailureShown() {
    assertEquals(422, checkout.checkoutStatus(), "Expected a payment-decline response");
    assertFalse(checkout.isOrderComplete(), "A declined payment must not show order confirmation");
    assertEquals("/cart", java.net.URI.create(world.driver.getCurrentUrl()).getPath());
    assertEquals(1, cart.itemCount(), "The cart should remain available for recovery");
    assertTrue(checkout.showsPaymentFailure(), "The customer should see the payment error and a recovery path");
  }
}