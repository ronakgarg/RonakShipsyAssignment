package org.opentelemetry.demo.ui.pages;

import org.opentelemetry.demo.ui.hooks.BrowserHooks;
import org.openqa.selenium.By;

public final class ProductPage extends BasePage {
  private static final By ADD_TO_CART = By.cssSelector("[data-cy='product-add-to-cart']");

  public ProductPage(BrowserHooks browser) {
    super(browser);
  }

  public void addToCart() {
    click(ADD_TO_CART);
    waitForUrlMatches(".*/cart/?(?:\\?.*)?");
  }
}