package org.opentelemetry.demo.ui.pages;

import org.opentelemetry.demo.ui.TestWorld;
import org.openqa.selenium.By;

public final class ProductPage extends BasePage {
  private static final By ADD_TO_CART = By.cssSelector("[data-cy='product-add-to-cart']");

  public ProductPage(TestWorld world) {
    super(world);
  }

  public void addToCart() {
    click(ADD_TO_CART);
    world.wait.until(driver -> driver.getCurrentUrl().matches(".*/cart/?(?:\\?.*)?"));
  }
}