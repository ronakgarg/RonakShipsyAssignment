package org.opentelemetry.demo.ui.steps;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.opentelemetry.demo.ui.hooks.BrowserHooks;
import org.opentelemetry.demo.ui.pages.CartPage;
import org.opentelemetry.demo.ui.pages.CheckoutPage;
import org.opentelemetry.demo.ui.pages.HomePage;
import org.opentelemetry.demo.ui.pages.ProductPage;

public class StorefrontSteps {
  private final BrowserHooks browser;
  private final HomePage home;
  private final ProductPage product;
  private final CartPage cart;
  private final CheckoutPage checkout;

  public StorefrontSteps(BrowserHooks browser) {
    this.browser = browser;
    home = new HomePage(browser);
    product = new ProductPage(browser);
    cart = new CartPage(browser);
    checkout = new CheckoutPage(browser);
  }

  @Given("the storefront is open")
  public void storefrontIsOpen() {
    home.waitForProducts();
    assertTrue(home.productCount() > 0, "The homepage should show products");
  }

  @When("I select EUR")
  public void selectEuro() {
    home.chooseCurrency("EUR");
  }

  @Then("product prices use the euro symbol")
  public void pricesUseEuro() {
    assertTrue(home.firstProductPrice().contains("€"), "Expected a EUR product price");
  }

  @When("I reload the storefront")
  public void reloadStorefront() {
    home.open();
  }

  @Then("EUR remains selected")
  public void euroRemainsSelected() {
    assertEquals("EUR", home.selectedCurrency());
  }

  @When("I add the first product twice")
  public void addFirstProductTwice() {
    home.openFirstProduct();
    product.addToCart();
    home.open();
    home.openFirstProduct();
    product.addToCart();
  }

  @Then("the cart shows one item with quantity {int}")
  public void cartShowsQuantity(int quantity) {
    cart.open();
    cart.waitForItems(1);
    assertEquals(Integer.toString(quantity), cart.quantities().get(0));
  }

  @When("I change the cart quantity to {int} and reload")
  public void changeQuantityAndReload(int quantity) {
    cart.setFirstQuantity(Integer.toString(quantity));
    browser.driver().navigate().refresh();
    cart.waitForItems(1);
  }

  @Given("the cart contains the first product")
  public void cartContainsFirstProduct() {
    home.openFirstProduct();
    product.addToCart();
    cart.waitForItems(1);
  }

  @When("I submit checkout with valid demo details")
  public void submitCheckout() {
    checkout.fillValidDemoDetails();
    checkout.submit();
  }

  @When("I submit checkout with invalid card details")
  public void submitCheckoutWithInvalidCardDetails() {
    checkout.fillInvalidCardDetails();
    checkout.submit();
  }

  @Then("the order confirmation includes an order ID and the cart is empty")
  public void orderConfirmedAndCartEmpty() {
    checkout.waitForOrderComplete();
    assertFalse(checkout.orderId().isBlank(), "Order confirmation should contain an order ID");
    cart.open();
    assertTrue(cart.isEmpty(), "The backend should have emptied the cart");
  }

  @Then("the invalid payment is rejected and no order confirmation appears")
  public void invalidPaymentIsRejected() {
    checkout.waitForPaymentFailure();
    assertFalse(checkout.isOrderComplete(), "An invalid card must not show order confirmation");
    assertEquals("/cart", java.net.URI.create(browser.driver().getCurrentUrl()).getPath());
    assertEquals(1, cart.itemCount(), "The cart should remain available for recovery");
  }
}